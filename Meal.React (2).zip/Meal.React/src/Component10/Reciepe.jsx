import React, { useState } from 'react';

const Recipe = () => {
    const [inpu, setInpu] = useState(""); 
    const [result, setResult] = useState([])
    const update = (e) => {
        setInpu(e.target.value);
    };

    const check = async () => {
        const query = inpu; 
        const api = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`);
        const res = await api.json();
        setResult(res.meals)
        console.log(res.meals);
    };
    
    //console.log(result)

    return (
        <>
            <div>
                <div className='mb-5 pb-1'>
                    <p className='text-orange-900 text-4xl font-bold text-center mt-5 mb-5'>Meal Menu</p>
                </div>

                <div className='flex justify-center'>
                    <div className='mr-3'>
                        <label className="input input-bordered flex items-center gap-2">
                            <input
                                type="text"
                                className="grow"
                                placeholder="Search"
                                list="meal-options"
                                onChange={update}
                                value={inpu}
                            />
                            <datalist id="meal-options">
                            <option value="Cake"></option>
                              <option value="Pizza"></option>
                              <option value="Burger"></option>
                              <option value="Pasta"></option>
                              <option value="Salad"></option>
                              <option value="Chocolate"></option>
                              <option value="Pudding"></option>
                              <option value="Soup"></option>
                              <option value="Sandwich"></option>
                              <option value="Chicken"></option>
                              <option value="Fish"></option>
                            </datalist>
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 16 16"
                                fill="currentColor"
                                className="h-4 w-4 opacity-70"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                                    clipRule="evenodd"
                                />
                            </svg>
                        </label>
                    </div>
                    <div>
                        <button className='btn bg-orange-600' onClick={check}>
                            Search
                        </button>
                    </div>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-5 ms-5 pe-5 ps-5 me-5 '>
                 {result.map((i)=>
                  <div className="card card-side bg-base-100 shadow-xl">
       
                  <>
                  <figure>
                    <img
                      src={i.strMealThumb
                      }
                      alt="Movie" />
                  </figure>
                  <div className="card-body">
                    <h2 className="card-title">{i.strMeal}</h2>
                    <p>{i.description}</p>
                   
                  </div>
                  </>
                  
                </div>
                 )}  
                </div>
            </div>
        </>
    );
};

export default Recipe;
